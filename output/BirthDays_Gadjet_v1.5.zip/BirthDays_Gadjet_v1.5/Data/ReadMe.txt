BirthDays_Gadget
-\-\-Ivan Stanchenko-/-/- 
Vastan96de@gmail.com

---------------------------------------------------------------------------------------------------------------------------------------------------------------------
Инструкция по установке и запуску.

1. Для установки гаджета скачайте архив с необходимой версией на ваш компьютер и распакуйте в удобное для Вас место (к примеру корень диска С:).
2. После чего запустите из папки файл:  BirthDays_Gadjet.exe
3. Гаджет запущен и должен отобразиться на вашем рабочем столе.
4. Для удобства можно создать ярлык для быстрого запуска или настроить автозапуск в интерфейсе программы.
5. Для добавления Ваших данных в программу Вы можете:
	* Добавить данные в ручную через интерфейс программы
	* Внести изменения в CSV-файл (./Data/Dates.csv)
	* Сформировать собственный CSV-файл и настроить работу гаджета через него (окно "Настройки")


При возникновении проблем с запуском или с идеями для новых версий можно писать на почту "Vastan96de@gmail.com"

---------------------------------------------------------------------------------------------------------------------------------------------------------------------
Installations- und Inbetriebnahmeanweisungen.

1. Um das Gadget zu installieren, laden Sie das Archiv mit der erforderlichen Version auf Ihren Computer herunter und 
   entpacken Sie es an einem für Sie geeigneten Ort (z. B. im Stammverzeichnis des Laufwerks C:).
2. Führen Sie dann die Datei aus dem Ordner aus: BirthDays_Gadjet.exe
3. Das Gadget wird gestartet und sollte auf Ihrem Desktop erscheinen.
4. Der Einfachheit halber können Sie eine Verknüpfung für den Schnellstart erstellen oder Autorun in der Programmoberfläche konfigurieren.
5. Um Ihre Daten zum Programm hinzuzufügen, können Sie:
	* Fügen Sie Daten manuell über die Programmoberfläche hinzu
	* Nehmen Sie Änderungen an der CSV-Datei (./Data/Dates.csv) vor.
	* Generieren Sie Ihre eigene CSV-Datei und konfigurieren Sie den Betrieb des Gadgets damit (Fenster „Einstellungen“)


Wenn Sie Probleme beim Start oder Ideen für neue Versionen haben, können Sie an „Vastan96de@gmail.com“ schreiben.

---------------------------------------------------------------------------------------------------------------------------------------------------------------------
Installation and launch instructions.

1. To install the gadget, download the archive with the required version to your computer and unzip it to a convenient location (for example, the root of drive C:).
2. Then run the file from the folder: BirthDays_Gadjet.exe
3. The gadget is launched and should appear on your desktop.
4. For convenience, you can create a shortcut for quick launch or set up autostart in the program interface.
5. To add your data to the program, you can:
	* Add data manually through the program interface
	* Make changes to the CSV file (./Data/Dates.csv)
	* Create your own CSV file and configure the gadget through it (the "Settings" window)

If you have problems with launching or with ideas for new versions, you can write to the email "Vastan96de@gmail.com"
